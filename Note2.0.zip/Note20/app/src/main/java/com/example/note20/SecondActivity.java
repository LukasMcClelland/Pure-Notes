package com.example.note20;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.io.FileOutputStream;
import java.util.Objects;

public class SecondActivity extends MainActivity {
    String filename;
    boolean markedForDeletion = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Intent intent = getIntent();
        filename = intent.getStringExtra("filename");
        Toolbar toolbar = findViewById(R.id.secondary_toolbar);
        toolbar.setTitle(filename);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        EditText editText = findViewById(R.id.editText);
        editText.setText(getStringFromFile(filename));
//        editText.requestFocus();
//        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    @Override
    protected void onPause(){
        super.onPause();
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(findViewById(R.id.editText).getWindowToken(), 0);
    }

    @Override
    protected void onStop(){
        super.onStop();
        if (!markedForDeletion) {
            EditText editText = findViewById(R.id.editText);
            String noteContents = editText.getText().toString();
            FileOutputStream fileOutputStream;
            try {
                fileOutputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                fileOutputStream.write(noteContents.getBytes());
                fileOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void finish(){
        if(!markedForDeletion) {
            EditText editText = findViewById(R.id.editText);
            String noteContents = editText.getText().toString();
            FileOutputStream fileOutputStream;
            try {
                fileOutputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                fileOutputStream.write(noteContents.getBytes());
                fileOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            Intent returnIntent = new Intent();
            returnIntent.putExtra("filename", filename);
            setResult(RESULT_OK, returnIntent);
        }
        else{
            Intent returnIntent = new Intent();
            returnIntent.putExtra("filename", filename);
            setResult(RESULT_CANCELED, returnIntent);
        }
        super.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.second_activity_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu){
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()) {
            case R.id.action_delete_note_button:
                presentDeletionDialog();
                return true;

            case R.id.action_delete_note:
                //User chose "Settings" item -> show the app settings UI
                Toast.makeText(getApplicationContext(), "Delete pressed", Toast.LENGTH_SHORT).show();
                presentDeletionDialog();
                return true;

            case R.id.action_share_note:
                Toast.makeText(getApplicationContext(), "Share pressed", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.action_convert_note:
                Toast.makeText(getApplicationContext(), "Convert pressed", Toast.LENGTH_SHORT).show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void presentDeletionDialog(){
        final AlertDialog dialogBuilder = new AlertDialog.Builder(this).create();
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.delete_note_alert, null);
        Button deleteNoteDialogButton = dialogView.findViewById(R.id.button_delete_note);
        Button cancelDialogButton = dialogView.findViewById(R.id.button_cancel_delete_note);


        deleteNoteDialogButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                markedForDeletion = true;
                dialogBuilder.dismiss();
                finish();
            }
        });

        cancelDialogButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                dialogBuilder.dismiss();
            }
        });
        dialogBuilder.setView(dialogView);
        dialogBuilder.show();
    }
}
